Deskripsi Aplikasi Toko Kelontong
Aplikasi Toko Kelontong adalah sebuah perangkat lunak berbasis desktop yang dirancang untuk mempermudah pengelolaan penjualan dan inventaris barang pada toko kelontong. Aplikasi ini dibangun menggunakan Python dengan antarmuka grafis berbasis Tkinter, serta mengintegrasikan MySQL untuk penyimpanan data.

Fitur utama aplikasi ini meliputi:
Manajemen Produk

Menambah produk baru ke dalam daftar inventaris.
Memperbarui informasi produk seperti nama, harga, dan stok.
Menghapus produk yang tidak lagi dijual.
Menampilkan daftar semua produk dalam bentuk tabel yang mudah dibaca.
Keranjang Belanja dan Pembelian

Menambahkan produk ke dalam keranjang belanja dengan jumlah yang diinginkan.
Melakukan pembelian langsung berdasarkan produk yang ada di keranjang.
Validasi stok barang secara otomatis untuk memastikan jumlah produk mencukupi sebelum pembelian dilakukan.
Transaksi dan Cetak Struk

Menyimpan detail transaksi yang meliputi produk yang dibeli, jumlah, total harga, dan tanggal pembelian.
Menampilkan struk belanja setelah pembelian selesai, memuat informasi daftar produk yang dibeli beserta rincian transaksi.
Antarmuka yang Sederhana dan Responsif

Desain antarmuka yang intuitif, sehingga memudahkan pengguna dari berbagai latar belakang untuk menggunakan aplikasi ini.
Tombol dan komponen dirancang dengan tata letak yang rapi agar nyaman digunakan.
Manfaat Aplikasi:

Membantu pemilik toko kelontong dalam mengelola stok barang secara efisien.
Mempermudah pencatatan transaksi harian tanpa perlu menggunakan cara manual.
Memberikan pengalaman pengguna yang lebih profesional dengan adanya fitur cetak struk belanja.
Aplikasi ini cocok digunakan untuk usaha kecil hingga menengah, dengan fleksibilitas yang dapat dikembangkan sesuai dengan kebutuhan pengguna.


Cara menjalankan aplikasi:
Manajemen Produk

Tambahkan produk baru dengan mengisi nama, harga, dan stok di bagian Manajemen Produk, lalu klik tombol Tambah Produk.
Untuk memperbarui produk, pilih salah satu produk di tabel, ubah detailnya, lalu klik Perbarui Produk.
Untuk menghapus produk, pilih produk dari tabel, lalu klik Hapus Produk.
Belanja Produk

Pilih produk yang tersedia di menu dropdown Pilih Produk.
Masukkan jumlah barang yang ingin dibeli di kolom Jumlah.
Klik tombol Tambah ke Keranjang untuk menambahkan barang ke keranjang belanja.
Setelah semua barang yang ingin dibeli masuk ke keranjang, klik tombol Beli.
Setelah pembelian selesai, struk belanja akan ditampilkan yang berisi daftar barang dan rincian pembelian.
Cetak Struk

Struk pembelian akan muncul dalam bentuk pop-up setelah pembelian berhasil dilakukan. Struk ini memuat:
Nama produk yang dibeli.
Jumlah barang dan harga total.
Tanggal pembelian.




Untuk struktur tabel database bisa dilihat langsung dalam
database.sql

contoh:
CREATE TABLE produk (
    ID_produk INT AUTO_INCREMENT PRIMARY KEY,  -- ID unik untuk setiap produk
    nama_produk VARCHAR(100) NOT NULL,         -- Nama produk
    harga_produk FLOAT NOT NULL,               -- Harga produk
    stok INT NOT NULL                          -- Stok produk
);

