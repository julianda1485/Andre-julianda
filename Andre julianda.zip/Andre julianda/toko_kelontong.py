import tkinter as tk
from tkinter import messagebox, ttk
import mysql.connector
from datetime import datetime

# Koneksi ke database MySQL
def connect_db():
    return mysql.connector.connect(
        host="localhost",
        user="root",  # Ganti dengan username MySQL Anda
        password="",  # Ganti dengan password MySQL Anda
        database="toko_kelontong"
    )

# Kelas untuk manajemen produk
class Produk:
    def __init__(self, id_produk, nama_produk, harga_produk, stok):
        self.id_produk = id_produk
        self.nama_produk = nama_produk
        self.harga_produk = harga_produk
        self.stok = stok

    @staticmethod
    def get_all_produk():
        db = connect_db()
        cursor = db.cursor()
        cursor.execute("SELECT * FROM produk")
        result = cursor.fetchall()
        db.close()
        return [Produk(*row) for row in result]

    @staticmethod
    def add_produk(nama_produk, harga_produk, stok):
        db = connect_db()
        cursor = db.cursor()
        cursor.execute("INSERT INTO produk (nama_produk, harga_produk, stok) VALUES (%s, %s, %s)", (nama_produk, harga_produk, stok))
        db.commit()
        db.close()

    @staticmethod
    def update_produk(id_produk, nama_produk, harga_produk, stok):
        db = connect_db()
        cursor = db.cursor()
        cursor.execute("UPDATE produk SET nama_produk = %s, harga_produk = %s, stok = %s WHERE ID_produk = %s", (nama_produk, harga_produk, stok, id_produk))
        db.commit()
        db.close()

    @staticmethod
    def delete_produk(id_produk):
        db = connect_db()
        cursor = db.cursor()
        cursor.execute("DELETE FROM produk WHERE ID_produk = %s", (id_produk,))
        db.commit()
        db.close()

    @staticmethod
    def update_stok(id_produk, jumlah):
        db = connect_db()
        cursor = db.cursor()

        # Ambil stok saat ini dari database
        cursor.execute("SELECT stok FROM produk WHERE ID_produk = %s", (id_produk,))
        current_stok = cursor.fetchone()
        if current_stok is None:
            db.close()
            raise ValueError("Produk tidak ditemukan!")

        current_stok = current_stok[0]

        # Periksa apakah stok mencukupi
        if jumlah > current_stok:
            db.close()
            raise ValueError("Stok tidak mencukupi untuk pembelian!")

        # Update stok
        cursor.execute("UPDATE produk SET stok = stok - %s WHERE ID_produk = %s", (jumlah, id_produk))
        db.commit()
        db.close()



# Kelas untuk manajemen transaksi
class Transaksi:
    def __init__(self, id_transaksi, id_produk, jumlah_harga, total_harga, tanggal_transaksi):
        self.id_transaksi = id_transaksi
        self.id_produk = id_produk
        self.jumlah_harga = jumlah_harga
        self.total_harga = total_harga
        self.tanggal_transaksi = tanggal_transaksi

    @staticmethod
    def save_transaksi(id_produk, jumlah_harga, total_harga):
        db = connect_db()
        cursor = db.cursor()
        tanggal_transaksi = datetime.now().date()
        cursor.execute("INSERT INTO transaksi (ID_produk, jumlah_harga, total_harga, tanggal_transaksi) VALUES (%s, %s, %s, %s)",
                       (id_produk, jumlah_harga, total_harga, tanggal_transaksi))
        db.commit()
        db.close()

# Kelas untuk aplikasi
class Aplikasi:
    def __init__(self, root):
        self.root = root
        self.root.title("Aplikasi Toko Kelontong")

        # Frame untuk manajemen produk
        self.frame_produk = tk.Frame(self.root)
        self.frame_produk.pack(pady=10)

        self.label_produk = tk.Label(self.frame_produk, text="Nama Produk:")
        self.label_produk.grid(row=0, column=0)

        self.entry_produk = tk.Entry(self.frame_produk)
        self.entry_produk.grid(row=0, column=1)

        self.label_harga = tk.Label(self.frame_produk, text="Harga Produk:")
        self.label_harga.grid(row=1, column=0)

        self.entry_harga = tk.Entry(self.frame_produk)
        self.entry_harga.grid(row=1, column=1)

        self.label_stok = tk.Label(self.frame_produk, text="Stok Produk:")
        self.label_stok.grid(row=2, column=0)

        self.entry_stok = tk.Entry(self.frame_produk)
        self.entry_stok.grid(row=2, column=1)

        self.button_tambah = tk.Button(self.frame_produk, text="Tambah Produk", command=self.tambah_produk)
        self.button_tambah.grid(row=3, column=0, columnspan=2)

        self.button_perbarui = tk.Button(self.frame_produk, text="Perbarui Produk", command=self.perbarui_produk)
        self.button_perbarui.grid(row=4, column=0, columnspan=2)

        self.button_hapus = tk.Button(self.frame_produk, text="Hapus Produk", command=self.hapus_produk)
        self.button_hapus.grid(row=5, column=0, columnspan=2)

        # Tabel produk
        self.tree_produk = ttk.Treeview(self.root, columns=("ID", "Nama", "Harga", "Stok"), show="headings")
        self.tree_produk.heading("ID", text="ID")
        self.tree_produk.heading("Nama", text="Nama Produk")
        self.tree_produk.heading("Harga", text="Harga")
        self.tree_produk.heading("Stok", text="Stok")
        self.tree_produk.pack(pady=10)

        self.tree_produk.bind("<ButtonRelease-1>", self.select_produk)

        # Frame untuk pembelian produk
        self.frame_beli = tk.Frame(self.root)
        self.frame_beli.pack(pady=10)

        self.label_pilih_produk = tk.Label(self.frame_beli, text="Pilih Produk:")
        self.label_pilih_produk.grid(row=0, column=0)

        self.combo_produk = ttk.Combobox(self.frame_beli)
        self.combo_produk.grid(row=0, column=1)

        self.label_jumlah = tk.Label(self.frame_beli, text="Jumlah:")
        self.label_jumlah.grid(row=1, column=0)

        self.entry_jumlah = tk.Entry(self.frame_beli)
        self.entry_jumlah.grid(row=1, column=1)

        self.button_tambah_keranjang = tk.Button(self.frame_beli, text="Tambah ke Keranjang", command=self.tambah_ke_keranjang)
        self.button_tambah_keranjang.grid(row=2, column=0, columnspan=2)

        # Keranjang
        self.label_keranjang = tk.Label(self.root, text="Keranjang:")
        self.label_keranjang.pack()

        self.tree_keranjang = ttk.Treeview(self.root, columns=("Nama", "Jumlah", "Total"), show="headings")
        self.tree_keranjang.heading("Nama", text="Nama Produk")
        self.tree_keranjang.heading("Jumlah", text="Jumlah")
        self.tree_keranjang.heading("Total", text="Total Harga")
        self.tree_keranjang.pack(pady=10)

        self.frame_keranjang_buttons = tk.Frame(self.root)
        self.frame_keranjang_buttons.pack(pady=10)

        self.button_beli = tk.Button(self.frame_keranjang_buttons, text="Beli", command=self.beli_produk)
        self.button_beli.grid(row=0, column=0, padx=5)

        self.button_tambah_keranjang = tk.Button(self.frame_keranjang_buttons, text="Tambah ke Keranjang", command=self.tambah_ke_keranjang)
        self.button_tambah_keranjang.grid(row=0, column=1, padx=5)

        self.keranjang = []

        self.load_produk()

    def load_produk(self):
        for row in self.tree_produk.get_children():
            self.tree_produk.delete(row)
        produk_list = Produk.get_all_produk()
        for produk in produk_list:
            self.tree_produk.insert("", tk.END, values=(produk.id_produk, produk.nama_produk, produk.harga_produk, produk.stok))
        self.combo_produk["values"] = [produk.nama_produk for produk in produk_list]

    def select_produk(self, event):
        selected = self.tree_produk.focus()
        if selected:
            values = self.tree_produk.item(selected, "values")
            self.entry_produk.delete(0, tk.END)
            self.entry_produk.insert(0, values[1])
            self.entry_harga.delete(0, tk.END)
            self.entry_harga.insert(0, values[2])
            self.entry_stok.delete(0, tk.END)
            self.entry_stok.insert(0, values[3])

    def tambah_produk(self):
        nama_produk = self.entry_produk.get()
        harga_produk = self.entry_harga.get()
        stok = self.entry_stok.get()

        if not nama_produk or not harga_produk or not stok:
            messagebox.showerror("Error", "Nama, harga, dan stok produk tidak boleh kosong!")
            return

        try:
            harga_produk = float(harga_produk)
            stok = int(stok)
            if stok < 0:
                messagebox.showerror("Error", "Stok tidak boleh bernilai negatif!")
                return

            Produk.add_produk(nama_produk, harga_produk, stok)
            messagebox.showinfo("Sukses", "Produk berhasil ditambahkan!")
            self.load_produk()
        except ValueError:
            messagebox.showerror("Error", "Harga dan stok harus berupa angka!")
        except Exception as e:
            messagebox.showerror("Error", f"Gagal menambahkan produk: {e}")


    def perbarui_produk(self):
        selected = self.tree_produk.focus()
        if selected:
            values = self.tree_produk.item(selected, "values")
            id_produk = values[0]
            nama_produk = self.entry_produk.get()
            harga_produk = self.entry_harga.get()
            stok = self.entry_stok.get()
            if nama_produk and harga_produk and stok:
                try:
                    Produk.update_produk(id_produk, nama_produk, float(harga_produk), int(stok))
                    messagebox.showinfo("Sukses", "Produk berhasil diperbarui!")
                    self.load_produk()
                except Exception as e:
                    messagebox.showerror("Error", f"Gagal memperbarui produk: {e}")
            else:
                messagebox.showerror("Error", "Nama, harga, dan stok produk tidak boleh kosong!")
        else:
            messagebox.showerror("Error", "Pilih produk yang ingin diperbarui!")

    def hapus_produk(self):
        selected = self.tree_produk.focus()
        if selected:
            values = self.tree_produk.item(selected, "values")
            id_produk = values[0]
            try:
                Produk.delete_produk(id_produk)
                messagebox.showinfo("Sukses", "Produk berhasil dihapus!")
                self.load_produk()
            except Exception as e:
                messagebox.showerror("Error", f"Gagal menghapus produk: {e}")
        else:
            messagebox.showerror("Error", "Pilih produk yang ingin dihapus!")

    def tambah_ke_keranjang(self):
        produk_list = Produk.get_all_produk()
        selected_produk = self.combo_produk.get()
        jumlah = self.entry_jumlah.get()

        if not selected_produk or not jumlah:
            messagebox.showerror("Error", "Pilih produk dan masukkan jumlah!")
            return

        try:
            jumlah = int(jumlah)
            if jumlah <= 0:
                messagebox.showerror("Error", "Jumlah harus bernilai positif!")
                return

            # Cari produk berdasarkan nama
            produk = next((p for p in produk_list if p.nama_produk == selected_produk), None)
            if produk is None:
                messagebox.showerror("Error", "Produk tidak ditemukan!")
                return

            # Validasi stok
            if jumlah > produk.stok:
                messagebox.showerror("Error", "Jumlah pembelian melebihi stok yang tersedia!")
                return

            # Tambahkan ke keranjang
            total_harga = jumlah * produk.harga_produk
            self.keranjang.append({"id": produk.id_produk, "nama": produk.nama_produk, "jumlah": jumlah, "total": total_harga})

            # Perbarui tabel keranjang
            self.tree_keranjang.insert("", tk.END, values=(produk.nama_produk, jumlah, total_harga))

            messagebox.showinfo("Sukses", "Produk berhasil ditambahkan ke keranjang!")
        except ValueError:
            messagebox.showerror("Error", "Jumlah harus berupa angka!")
        except Exception as e:
            messagebox.showerror("Error", f"Gagal menambahkan ke keranjang: {e}")

    def beli_produk(self):
        if not self.keranjang:
            messagebox.showerror("Error", "Keranjang masih kosong!")
            return

        try:
            struk = "Struk Pembelian\n"
            struk += f"Tanggal: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            struk += "================================\n"

            for item in self.keranjang:
                Produk.update_stok(item["id"], item["jumlah"])
                Transaksi.save_transaksi(item["id"], item["jumlah"], item["total"])
                struk += f"{item['nama']} - Jumlah: {item['jumlah']} - Total: Rp{item['total']}\n"

            struk += "================================\n"
            total_bayar = sum(item["total"] for item in self.keranjang)
            struk += f"Total Bayar: Rp{total_bayar}\n"

            self.keranjang.clear()

            # Kosongkan tabel keranjang
            for row in self.tree_keranjang.get_children():
                self.tree_keranjang.delete(row)

            messagebox.showinfo("Sukses", struk)
            self.load_produk()
        except Exception as e:
            messagebox.showerror("Error", f"Gagal menyelesaikan pembelian: {e}")

if __name__ == "__main__":
    root = tk.Tk()
    app = Aplikasi(root)
    root.mainloop()
